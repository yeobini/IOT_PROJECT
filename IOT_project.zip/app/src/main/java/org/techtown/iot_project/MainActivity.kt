package org.techtown.iot_project

import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.techtown.iot_project.databinding.ActivityMainBinding
import org.techtown.iot_project.databinding.MonitorBinding
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.Socket

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fun sendText(text: String) {
            val model = LightModel(text)
            GlobalScope.launch(Dispatchers.IO) {
                try {
                    if(text == "/On"){
                        val response = LightObject.getRetrofitLightService.controlOn(LightModel(text.toString()))
                        if (response.isSuccessful){
                            Log.d("success","data sent successfully")
                        } else {
                            Log.e("error","failed to send data")
                        }
                    } else if(text == "/Off"){
                        val response = LightObject.getRetrofitLightService.controlOff(LightModel(text.toString()))
                        if (response.isSuccessful){
                            Log.d("success","data sent successfully")
                        } else {
                            Log.e("error","failed to send data")
                        }
                    } else if(text == "/Switch"){
                        val response = LightObject.getRetrofitLightService.control(LightModel(text.toString()))
                        if (response.isSuccessful){
                            Log.d("success","data sent successfully")
                        } else {
                            Log.e("error","failed to send data")
                        }
                    }
                } catch (e: IOException){
                    Log.e("error", "IOException: ${e.message}")
                }
            }
        }

        binding.monitorBtn.setOnClickListener{
            val intent = Intent(this, MonitorActivity::class.java)
            startActivity(intent)
        }
        binding.diaryBtn.setOnClickListener{
            val intent = Intent(this, CameraActivity::class.java)
            startActivity(intent)
        }

        binding.ledOn.setOnClickListener{
            var text = "/On"
            sendText(text)
            text = "/Switch"
            Handler(Looper.getMainLooper()).postDelayed({
                sendText(text)
            }, 200)
        }
        binding.ledOff.setOnClickListener {
            var text = "/Off"
            sendText(text)
            text = "/Switch"
            Handler(Looper.getMainLooper()).postDelayed({
                sendText(text)
            }, 200)
        }

        Thread{
            try {
                val socket = Socket("172.30.1.29", 8080)//아두이노 WIFIfiserver server(80)부분 수정
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                val response = reader.readLine()
                while(true){
                    val dataArray = response.split(" ")//온도, 습도, 몸무게 분리
                    val temperature = dataArray[1] // 온도 값
                    val humidity = dataArray[3] // 습도 값
                    val weight = dataArray[5] // 몸무게 값
                    runOnUiThread {
                        binding.temperature.text = response
                        binding.temperature.text = "$temperature °C"
                        binding.humidity.text = "$humidity %"
                        binding.weight.text = "$weight kg"
                    }
                }

                reader.close()
                socket.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }
}