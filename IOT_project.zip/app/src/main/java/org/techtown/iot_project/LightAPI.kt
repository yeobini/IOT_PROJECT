package org.techtown.iot_project

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface LightAPI {
    @POST("On")
    suspend fun controlOn(@Body smartFarmModel: LightModel): Response<Void> //retrofit임 okhttp연결아니고

    @POST("Off")
    suspend fun controlOff(@Body smartFarmModel: LightModel): Response<Void>

    @POST("Switch")
    suspend fun control(@Body smartFarmModel: LightModel): Response<Void>
}