package org.techtown.iot_project

import android.os.Handler
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.Socket

class TcpThread(private val handler: Handler) : Thread() {
    private var dataInputStream: InputStream? = null
    private var dataOutputStream: OutputStream? = null
    private var socket: Socket? = null
    private val ip = "172.30.1.29"
    private val port = 8080
    private val TAG = "TAG+Thread"

    override fun run() {
        try {
            Log.d(TAG, "접속")
            socket = Socket(ip, port).also {
                dataOutputStream = it.getOutputStream()
                dataInputStream = it.getInputStream()
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }

        val buffer = ByteArray(1024)
        var bytes: Int
        var tmp: String

        Log.d(TAG, "수신 시작")
        while (true) {
            try {
                Log.d(TAG, "수신 대기")
                bytes = dataInputStream?.read(buffer) ?: -1
                Log.d(TAG, "byte = $bytes")
                if (bytes > 0) {
                    tmp = String(buffer, 0, bytes)
                } else {
                    Log.d(TAG, "재접속")
                    socket = Socket(ip, port).also {
                        dataOutputStream = it.getOutputStream()
                        dataInputStream = it.getInputStream()
                    }
                    continue
                }
                Log.d(TAG, tmp)
                handler.obtainMessage(0, tmp).sendToTarget()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }

    @Throws(IOException::class)
    fun cctvOn() {
        val inst = "cctvOn".toByteArray()
        dataOutputStream?.write(inst)
    }

}