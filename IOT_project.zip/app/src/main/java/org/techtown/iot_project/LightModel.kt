package org.techtown.iot_project

import com.google.gson.annotations.SerializedName

data class LightModel(
    @SerializedName("switch")
    val ledControll: String,
)
