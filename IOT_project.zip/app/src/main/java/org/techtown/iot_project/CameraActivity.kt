package org.techtown.iot_project

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.hardware.Camera
import android.os.Bundle
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.FileOutputStream
import java.io.IOException

class CameraActivity : AppCompatActivity(), SurfaceHolder.Callback {

    private lateinit var camera: Camera
    private lateinit var surfaceHolder: SurfaceHolder
    private lateinit var captureButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.diary)

        // 권한 확인 및 요청
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), CAMERA_PERMISSION_REQUEST_CODE)
        }

        // SurfaceView 및 SurfaceHolder 초기화
        val surfaceView = findViewById<SurfaceView>(R.id.cameraPreview)
        surfaceHolder = surfaceView.holder
        surfaceHolder.addCallback(this)

        // 사진 촬영 버튼 초기화
        captureButton = findViewById(R.id.captureButton)
        captureButton.setOnClickListener {
            takePicture()
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        try {
            // 카메라 초기화
            camera = Camera.open()
            camera.setDisplayOrientation(90)
            camera.setPreviewDisplay(holder)
            camera.startPreview()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        // 카메라 미리 보기 종료
        camera.stopPreview()
        camera.release()
    }

    private fun takePicture() {
        // 사진 촬영
        camera.takePicture(null, null, Camera.PictureCallback { data, _ ->
            try {
                // 촬영한 사진을 저장
                val fos = FileOutputStream("파일경로/photo.jpg")
                fos.write(data)
                fos.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
            // 사진 찍은 후 미리 보기 재시작
            camera.startPreview()
        })
    }

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 100
    }

}