package org.techtown.iot_project

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import org.techtown.iot_project.databinding.MonitorBinding

class MonitorActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = MonitorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.goHome.setOnClickListener{
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        binding.onBtn.setOnClickListener{

        }

    }
}